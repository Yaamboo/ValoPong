It's like Pong, but with Instanssi event lights!

First version, so this will only work with the light server at Instanssi 2013 festival.

Use the spacebar to control the left player (red light) and numpad-enter to control the right player (blue light).